import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

const TypewriterText = ({ text, speed = 30 }) => {
    const [displayedText, setDisplayedText] = useState('');
    const indexRef = useRef(0);
    const textRef = useRef(text); // Guardar referencia al texto actual

    useEffect(() => {
        textRef.current = text;
        indexRef.current = 0;
        setDisplayedText('');

        if (!text) return;

        const intervalId = setInterval(() => {
            if (indexRef.current < textRef.current.length) {
                setDisplayedText((prev) => prev + textRef.current.charAt(indexRef.current));
                indexRef.current++;
            } else {
                clearInterval(intervalId);
            }
        }, speed);

        return () => clearInterval(intervalId);
    }, [text, speed]);

    return (
        <span className="inline leading-relaxed">
            {displayedText}
            {indexRef.current < text.length && (
                <motion.span
                    initial={{ opacity: 0 }}
                    animate={{ opacity: [0, 1, 0] }}
                    transition={{ duration: 0.8, repeat: Infinity }}
                    className="inline-block w-2 h-5 ml-1 bg-blue-400 align-middle"
                />
            )}
        </span>
    );
};

export default TypewriterText;
