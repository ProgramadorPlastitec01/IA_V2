import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence, useMotionValue, useTransform } from 'framer-motion';
import notebookLMClient from '../utils/notebookLMClient';
import NexusCore from './NexusCore';
import CompanyLogo from './CompanyLogo';
import TypewriterText from './TypewriterText';

const VoiceChat = () => {
    const [isActivated, setIsActivated] = useState(false);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [state, setState] = useState('idle'); // idle, listening, thinking, speaking
    const [transcript, setTranscript] = useState('');
    const [response, setResponse] = useState('');
    const [error, setError] = useState('');

    const [isSupported, setIsSupported] = useState(true);
    const volume = useMotionValue(0);
    const visualizerScale = useTransform(volume, [0, 200], [1, 2]);
    const visualizerOpacity = useTransform(volume, [0, 20], [0, 0.5]);
    const [debugLogs, setDebugLogs] = useState([]);
    const [showDebug, setShowDebug] = useState(false); // Debug oculto por defecto

    // Sistema de logs en pantalla
    const addLog = (message, type = 'info') => {
        const timestamp = new Date().toLocaleTimeString();
        const icon = type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️';
        const newLog = `${icon} [${timestamp}] ${message}`;

        console.log(message); // Mantener consola original
        setDebugLogs(prev => [newLog, ...prev].slice(0, 100)); // Guardar últimos 100 logs
    };

    const recognitionRef = useRef(null);
    const synthRef = useRef(window.speechSynthesis);
    const recognitionTimeoutRef = useRef(null); // Timeout de seguridad para móviles
    const hasReceivedResultRef = useRef(false); // Para detectar si hubo resultados en la sesión actual
    const lastInterimResultRef = useRef(''); // Para guardar el último resultado parcial

    // Refs recuperados
    const streamRef = useRef(null);
    const inactivityTimerRef = useRef(null);
    const ttsInProgressRef = useRef(false);

    // Refs para visualizador
    const animationFrameRef = useRef(null);
    const analyserRef = useRef(null);
    const audioContextRef = useRef(null);
    const abortControllerRef = useRef(null); // Controlador de peticiones para cancelar consultas anteriores

    // Configuración de MediaRecorder para móviles
    const mediaRecorderRef = useRef(null);
    const audioChunksRef = useRef([]);
    const recordingTimeoutRef = useRef(null);
    const forceWebSpeechMode = useRef(false);

    // Función auxiliar para iniciar visualizador
    const startVisualizer = (stream) => {
        try {
            if (!audioContextRef.current) {
                audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
            }
            if (audioContextRef.current.state === 'suspended') {
                audioContextRef.current.resume();
            }

            // Si ya hay analyser, reutilizarlo o recrearlo
            if (!analyserRef.current) {
                analyserRef.current = audioContextRef.current.createAnalyser();
                analyserRef.current.fftSize = 256;
            }

            const source = audioContextRef.current.createMediaStreamSource(stream);
            source.connect(analyserRef.current);

            const bufferLength = analyserRef.current.frequencyBinCount;
            const dataArray = new Uint8Array(bufferLength);

            const updateVolume = () => {
                if (analyserRef.current) {
                    analyserRef.current.getByteFrequencyData(dataArray);
                    let sum = 0;
                    for (let i = 0; i < bufferLength; i++) {
                        sum += dataArray[i];
                    }
                    const average = sum / bufferLength;
                    volume.set(average * 2.5); // Actualizar MotionValue directamente
                    animationFrameRef.current = requestAnimationFrame(updateVolume);
                }
            };
            updateVolume();
            addLog('📊 Visualizador de audio iniciado', 'info');
        } catch (e) {
            console.error('Error al iniciar visualizador:', e);
            addLog(`❌ Error visualizador: ${e.message}`, 'error');
        }
    };

    // Detección mejorada de dispositivos móviles
    const isMobileDevice = useRef((() => {
        const ua = navigator.userAgent;
        const isMobileUA = /iPhone|iPad|iPod|Android|webOS|BlackBerry|IEMobile|Opera Mini/i.test(ua);
        const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
        const isSmallScreen = window.innerWidth <= 768;

        const mobileScore = (isMobileUA ? 1 : 0) + (isTouchDevice ? 1 : 0) + (isSmallScreen ? 1 : 0);
        const isMobile = mobileScore >= 2 || /Android/i.test(ua);

        if (typeof window !== 'undefined') {
            console.log('🔍 DETECCIÓN DE DISPOSITIVO (MEJORADA):', isMobile ? '📱 MÓVIL' : '🖥️ DESKTOP');
        }

        return isMobile;
    })());

    useEffect(() => {
        if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
            setIsSupported(false);
            addLog('Navegador no soporta Web Speech API', 'error');
            setError('Tu navegador no soporta reconocimiento de voz. Por favor usa Chrome o Edge.');
            return;
        }

        addLog('Iniciando VoiceChat...', 'info');
        notebookLMClient.initialize();

        return () => {
            if (recognitionRef.current) recognitionRef.current.stop();
            if (synthRef.current) synthRef.current.cancel();
            if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
            if (audioContextRef.current) audioContextRef.current.close();
            if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
            if (recognitionTimeoutRef.current) clearTimeout(recognitionTimeoutRef.current);
        };
    }, []);

    // INACTIVITY LOGIC
    const resetInactivityTimer = () => {
        if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
        if (!isActivated) return;
        if (state === 'thinking' || state === 'speaking') return;

        inactivityTimerRef.current = setTimeout(() => {
            handleInactivityTimeout();
        }, 30000);
    };

    const handleInactivityTimeout = () => {
        console.log("Inactivity detected. Resetting to standby mode.");
        setIsActivated(false);
        setState('idle');
        setTranscript('');
        setResponse('');
        if (synthRef.current) synthRef.current.cancel();
        if (recognitionRef.current) recognitionRef.current.stop();
    };

    useEffect(() => {
        resetInactivityTimer();
    }, [state, isActivated, transcript, response]);

    useEffect(() => {
        if (!isActivated) return;
        const events = ['mousemove', 'mousedown', 'keydown', 'touchstart'];
        const handleUserActivity = () => resetInactivityTimer();
        events.forEach(event => window.addEventListener(event, handleUserActivity));
        return () => {
            events.forEach(event => window.removeEventListener(event, handleUserActivity));
        };
    }, [isActivated]);


    const speakText = async (text) => {
        if (ttsInProgressRef.current) {
            console.warn('⚠️ Ya hay una síntesis de voz en progreso.');
            return;
        }

        try {
            ttsInProgressRef.current = true;
            if (synthRef.current) synthRef.current.cancel();
            await new Promise(resolve => setTimeout(resolve, 100));

            const utterance = new SpeechSynthesisUtterance(text);
            const voices = synthRef.current.getVoices();

            let selectedVoice = voices.find(voice => voice.lang.includes('es-MX') || voice.lang.includes('es-US'));
            if (!selectedVoice) selectedVoice = voices.find(voice => voice.lang.includes('es-ES'));
            if (!selectedVoice) selectedVoice = voices.find(voice => voice.lang.startsWith('es'));

            if (selectedVoice) utterance.voice = selectedVoice;

            utterance.rate = 1.0;
            utterance.pitch = 1.0;
            utterance.volume = 1.0;
            utterance.lang = selectedVoice ? selectedVoice.lang : 'es-ES';

            utterance.onstart = () => console.log('🎵 REPRODUCIENDO VOZ');
            utterance.onend = () => {
                console.log('✅ Reproducción completada');
                ttsInProgressRef.current = false;
                setState('idle');
                setTranscript('');
                setResponse('');
            };
            utterance.onerror = (event) => {
                console.error('❌ Error en síntesis de voz:', event.error);
                ttsInProgressRef.current = false;
                setState('idle');
                setError('Error al generar la voz.');
            };

            synthRef.current.speak(utterance);

        } catch (err) {
            console.error('ERROR EN SÍNTESIS DE VOZ:', err);
            ttsInProgressRef.current = false;
            setState('idle');
            setError('❌ Error al generar voz.');
        }
    };

    const handleQuery = async (text) => {
        if (!text) {
            addLog('⚠️ handleQuery llamado con texto vacío', 'warning');
            return;
        }

        addLog(`🧠 Procesando consulta: "${text}"`, 'info');
        setTranscript(text);
        setResponse('');
        setError('');
        setState('thinking');

        if (synthRef.current) synthRef.current.cancel();

        try {
            if (abortControllerRef.current) abortControllerRef.current.abort();
            abortControllerRef.current = new AbortController();

            addLog('📡 Enviando petición a NotebookLM...', 'info');
            const aiResponse = await notebookLMClient.query(text, {
                signal: abortControllerRef.current.signal
            });

            if (!aiResponse || aiResponse.trim().length === 0) {
                throw new Error('La IA devolvió una respuesta vacía.');
            }

            addLog(`✅ Respuesta recibida (${aiResponse.length} chars)`, 'success');
            setResponse(aiResponse);
            setState('speaking');
            speakText(aiResponse);
        } catch (err) {
            if (err.name === 'AbortError') {
                addLog('⏹️ Consulta cancelada por el usuario', 'info');
                return;
            }
            console.error('Error en handleQuery:', err);
            addLog(`❌ Error en consulta: ${err.message}`, 'error');
            setError(err.message || 'Hubo un error al procesar tu consulta.');
            setState('idle');
        } finally {
            abortControllerRef.current = null;
        }
    };

    const stopListening = () => {
        if (recognitionRef.current) recognitionRef.current.stop();
        if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
        if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
            abortControllerRef.current = null;
        }
        volume.set(0);
        setState('idle');
    };

    // Transcribir audio usando OpenAI Whisper API (para móviles)
    const transcribeAudio = async (audioBlob) => {
        try {
            setState('thinking');
            const formData = new FormData();
            formData.append('audio', audioBlob, 'recording.webm');

            const response = await fetch('/api/transcribe', {
                method: 'POST',
                body: formData
            });

            if (!response.ok) {
                const errorData = await response.json();
                if (errorData.fallbackToWebSpeech) {
                    forceWebSpeechMode.current = true;
                    setError('⚠️ Límite de API alcanzado. Cambiando a reconocimiento ilimitado del navegador.');
                    setState('idle');
                    setTimeout(() => startListening(), 1500);
                    return;
                }
                throw new Error(errorData.error || 'Error al transcribir audio');
            }

            const data = await response.json();
            const transcript = data.transcript;
            setTranscript(transcript);
            await handleQuery(transcript);

        } catch (err) {
            setError(`❌ Error al transcribir: ${err.message}`);
            setState('idle');
        }
    };

    const stopRecording = () => {
        if (recordingTimeoutRef.current) clearTimeout(recordingTimeoutRef.current);
        if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
            mediaRecorderRef.current.stop();
        }
    };

    const startRecording = async () => {
        try {
            setError('');
            setTranscript('');
            setResponse('');
            setState('listening');

            const stream = await navigator.mediaDevices.getUserMedia({
                audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
            });
            streamRef.current = stream;

            // Visualizador
            audioContextRef.current = new (window.AudioContext || window.webkitAudioContext)();
            analyserRef.current = audioContextRef.current.createAnalyser();
            const source = audioContextRef.current.createMediaStreamSource(stream);
            source.connect(analyserRef.current);
            analyserRef.current.fftSize = 256;

            const bufferLength = analyserRef.current.frequencyBinCount;
            const dataArray = new Uint8Array(bufferLength);

            const updateVolume = () => {
                if (analyserRef.current && audioContextRef.current.state === 'running') {
                    analyserRef.current.getByteFrequencyData(dataArray);
                    let sum = 0;
                    for (let i = 0; i < bufferLength; i++) sum += dataArray[i];
                    volume.set((sum / bufferLength) * 2.5);
                    animationFrameRef.current = requestAnimationFrame(updateVolume);
                }
            };
            updateVolume();

            // MediaRecorder
            audioChunksRef.current = [];
            let mimeType = '';
            if (MediaRecorder.isTypeSupported('audio/mp4')) mimeType = 'audio/mp4';
            else if (MediaRecorder.isTypeSupported('audio/webm')) mimeType = 'audio/webm';

            mediaRecorderRef.current = new MediaRecorder(stream, mimeType ? { mimeType } : {});
            mediaRecorderRef.current.ondataavailable = (event) => {
                if (event.data.size > 0) audioChunksRef.current.push(event.data);
            };
            mediaRecorderRef.current.onstop = async () => {
                if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
                if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
                if (audioContextRef.current) audioContextRef.current.close();
                volume.set(0);

                const audioBlob = new Blob(audioChunksRef.current, { type: mimeType });
                await transcribeAudio(audioBlob);
            };

            mediaRecorderRef.current.start();
            recordingTimeoutRef.current = setTimeout(() => stopRecording(), 10000);

        } catch (err) {
            console.error('ERROR AL INICIAR GRABACIÓN:', err);
            if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
            setError('❌ Error al iniciar grabación.');
            setState('idle');
        }
    };

    const startListening = async () => {
        if (!isSupported) return;

        // Si es móvil y tenemos Whisper configurado (o no forzado a web speech), usar grabación
        // NOTA: Para este tutorial simplificado, usaremos siempre Web Speech API excepto si se pide explícitamente lo contrario
        // Pero mantengo la estructura lógica aquí por si acaso.
        /* 
        if (isMobileDevice.current && !forceWebSpeechMode.current) {
             startRecording();
             return;
        }
        */

        setError('');
        setTranscript('');
        setResponse('');
        setState('listening');
        hasReceivedResultRef.current = false;
        lastInterimResultRef.current = '';

        recognitionTimeoutRef.current = setTimeout(() => {
            console.warn('⏱️ TIMEOUT');
            if (recognitionRef.current) recognitionRef.current.stop();
        }, 15000);

        try {
            if (!isMobileDevice.current) {
                const stream = await navigator.mediaDevices.getUserMedia({
                    audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
                });
                streamRef.current = stream;
                startVisualizer(stream);
            }

            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognitionRef.current = new SpeechRecognition();
            recognitionRef.current.continuous = false;
            recognitionRef.current.interimResults = true;
            recognitionRef.current.lang = navigator.language || 'es-ES';

            recognitionRef.current.onstart = () => setState('listening');

            recognitionRef.current.onresult = (event) => {
                if (recognitionTimeoutRef.current) {
                    clearTimeout(recognitionTimeoutRef.current);
                    recognitionTimeoutRef.current = setTimeout(() => {
                        if (recognitionRef.current) recognitionRef.current.stop();
                    }, 5000);
                }

                const result = event.results[event.results.length - 1];
                const transcriptText = result[0].transcript;
                lastInterimResultRef.current = transcriptText;
                setTranscript(transcriptText);

                if (result.isFinal) {
                    hasReceivedResultRef.current = true;
                    if (recognitionRef.current) recognitionRef.current.stop();
                    handleQuery(transcriptText);
                }
            };

            recognitionRef.current.onerror = (event) => {
                console.error('Error WebSpeech:', event.error);
                clearTimeout(recognitionTimeoutRef.current);
                if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());

                if (event.error === 'no-speech') setError('No se detectó voz.');
                else setError(`Error: ${event.error}`);

                setState('idle');
            };

            recognitionRef.current.onend = () => {
                if (recognitionTimeoutRef.current) clearTimeout(recognitionTimeoutRef.current);
                if (streamRef.current) {
                    try {
                        streamRef.current.getTracks().forEach(track => track.stop());
                        streamRef.current = null;
                    } catch (e) { console.warn(e); }
                }
                if (animationFrameRef.current) cancelAnimationFrame(animationFrameRef.current);
                volume.set(0);

                if (!hasReceivedResultRef.current && lastInterimResultRef.current) {
                    setTranscript(lastInterimResultRef.current);
                    handleQuery(lastInterimResultRef.current);
                } else if (!hasReceivedResultRef.current) {
                    setState('idle');
                }
            };

            recognitionRef.current.start();

        } catch (err) {
            console.error('ERROR AL INICIAR RECONOCIMIENTO:', err);
            clearTimeout(recognitionTimeoutRef.current);
            if (streamRef.current) streamRef.current.getTracks().forEach(track => track.stop());
            setError('❌ Error al iniciar reconocimiento.');
            setState('idle');
        }
    };

    const getStateConfig = () => {
        switch (state) {
            case 'listening':
                return {
                    icon: '🎙️',
                    text: 'Te escucho...',
                    subtext: 'Habla ahora',
                    color: 'text-green-400',
                    borderColor: 'border-green-500/50',
                    bgGlow: 'shadow-[0_0_100px_rgba(74,222,128,0.2)]'
                };
            case 'thinking':
                return {
                    icon: '🧠',
                    text: 'Procesando...',
                    subtext: 'Analizando documentos...',
                    color: 'text-blue-400',
                    borderColor: 'border-blue-500/50',
                    bgGlow: 'shadow-[0_0_100px_rgba(96,165,250,0.2)]'
                };
            case 'speaking':
                return {
                    icon: '🗣️',
                    text: 'Respondiendo',
                    subtext: 'Escucha la respuesta',
                    color: 'text-purple-400',
                    borderColor: 'border-purple-500/50',
                    bgGlow: 'shadow-[0_0_100px_rgba(192,132,252,0.2)]'
                };
            default:
                return {
                    icon: '✨',
                    text: 'Bienvenido',
                    subtext: 'Toca el micrófono para comenzar',
                    color: 'text-white',
                    borderColor: 'border-white/10',
                    bgGlow: ''
                };
        }
    };

    const config = getStateConfig();

    if (!isActivated) {
        return (
            <div
                className="h-screen w-full flex flex-col items-center justify-center bg-[#0d1426] cursor-pointer overflow-hidden relative"
                onClick={() => setIsActivated(true)}
            >
                <div className="absolute inset-0 z-0">
                    <NexusCore status="idle" volume={0} />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#0d1426] via-transparent to-[#0d1426]/80"></div>
                </div>

                <div className="relative z-10 text-center space-y-12 animate-in fade-in zoom-in duration-1000 p-8 glass-effect rounded-[3rem] border border-white/5 shadow-2xl">
                    <div className="flex flex-col items-center gap-6">
                        <CompanyLogo size={180} className="mb-4 drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]" />
                        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-400/30 rounded-full backdrop-blur-sm">
                            <span className="w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></span>
                            <span className="text-xs font-semibold text-yellow-300 tracking-wider uppercase">Versión Demo</span>
                        </div>
                        <div>
                            <h1 className="text-4xl font-light text-white tracking-[0.5em] uppercase">
                                Asistente <span className="font-bold text-blue-400">RRHH</span>
                            </h1>
                        </div>
                    </div>
                    <div>
                        <div className="inline-flex items-center gap-4 px-12 py-6 bg-white/5 border border-white/10 rounded-full text-white text-xl backdrop-blur-md hover:bg-white/10 transition-all group shadow-[0_0_30px_rgba(0,0,0,0.5)]">
                            <span className="group-hover:tracking-widest transition-all duration-300">TOCAR PARA INICIAR</span>
                            <span className="text-2xl animate-pulse">👆</span>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="h-screen w-full bg-[#0d1426] overflow-hidden relative font-sans text-white">
            <div className={`absolute inset-0 flex items-center justify-center transition-all duration-500 will-change-transform ${response ? 'opacity-20 scale-150' : 'opacity-100 scale-100'}`}>
                <NexusCore status={state} volume={volume} />
            </div>

            <div className="relative z-10 h-full flex flex-col p-4 md:p-6 lg:p-12">
                <div className="flex justify-between items-start flex-wrap gap-3">
                    <div className="flex items-center gap-2 md:gap-4">
                        <div className="flex items-center gap-3 md:gap-6 bg-black/30 backdrop-blur-md p-2 md:p-4 pr-4 md:pr-8 rounded-full border border-white/5">
                            <CompanyLogo size={window.innerWidth < 768 ? 40 : 60} />
                            <div className="flex flex-col">
                                <span className="text-[10px] md:text-xs text-blue-300 font-bold tracking-[0.2em] md:tracking-[0.3em] uppercase">Asistente Virtual</span>
                                <span className="text-[8px] md:text-[10px] text-white/40 uppercase tracking-wider">Recursos Humanos</span>
                            </div>
                        </div>
                        <div className="flex items-center gap-1 md:gap-1.5 px-2 md:px-3 py-1 md:py-1.5 bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-400/30 rounded-full backdrop-blur-sm">
                            <span className="w-1 md:w-1.5 h-1 md:h-1.5 bg-yellow-400 rounded-full animate-pulse"></span>
                            <span className="text-[9px] md:text-[10px] font-semibold text-yellow-300 tracking-wider uppercase">Demo</span>
                        </div>
                    </div>
                    <button onClick={() => setIsModalOpen(true)} className="w-10 h-10 md:w-12 md:h-12 flex items-center justify-center bg-white/5 border border-white/10 rounded-full hover:bg-white/10 transition-colors backdrop-blur-md text-lg md:text-xl">
                        ℹ️
                    </button>
                </div>

                <div className="flex-grow flex flex-col items-center justify-center relative my-4">
                    {!response && (
                        <div className={`text-center space-y-4 transition-transform duration-500 will-change-transform ${state === 'listening' ? 'scale-110' : 'scale-100'}`}>
                            <div className={`text-6xl mb-4 ${state === 'thinking' ? 'animate-bounce' : ''}`}>
                                {config.icon}
                            </div>
                            <h2 className={`text-4xl font-light ${config.color}`}>{config.text}</h2>
                            <p className="text-white/40 text-lg tracking-wider">{config.subtext}</p>
                        </div>
                    )}

                    <AnimatePresence>
                        {response && (
                            <motion.div
                                initial={{ opacity: 0, y: 50, scale: 0.9 }}
                                animate={{ opacity: 1, y: 0, scale: 1 }}
                                exit={{ opacity: 0, scale: 0.9 }}
                                className="w-full max-w-5xl bg-[#1a2333]/90 backdrop-blur-xl border border-white/10 rounded-2xl md:rounded-[3rem] p-6 md:p-10 lg:p-14 shadow-2xl flex flex-col max-h-[60vh] md:max-h-[65vh] will-change-transform"
                            >
                                <div className="overflow-y-auto custom-scrollbar pr-3 md:pr-6 space-y-4 md:space-y-6 flex-grow">
                                    <h3 className="text-xs md:text-sm font-bold text-blue-400 uppercase tracking-widest sticky top-0 bg-[#1a2333]/95 py-2 z-10">Respuesta:</h3>
                                    <div className="text-lg md:text-2xl lg:text-3xl font-light leading-relaxed text-slate-100 min-h-[4rem]">
                                        <TypewriterText text={response} speed={25} />
                                    </div>
                                </div>
                                <div className="mt-6 md:mt-8 pt-4 md:pt-6 border-t border-white/5 flex flex-col gap-2 md:gap-3">
                                    <div className="text-white/30 text-[10px] md:text-xs italic flex flex-col md:flex-row justify-between gap-2">
                                        <span className="truncate">Tu consulta: "{transcript}"</span>
                                        <span>v1.0</span>
                                    </div>
                                    <div className="text-center">
                                        <p className="text-[10px] md:text-xs font-bold text-red-300/90 bg-red-500/10 border border-red-500/20 px-3 md:px-4 py-1.5 md:py-2 rounded-lg inline-block">
                                            ⚠️ La respuesta por IA puede contener errores.
                                        </p>
                                    </div>
                                </div>
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>

                <div className="w-full max-w-3xl mx-auto flex items-center gap-4 md:gap-6 bg-black/40 backdrop-blur-lg border border-white/10 rounded-full p-2 md:p-3 pr-4 md:pr-8 shadow-[0_10px_40px_rgba(0,0,0,0.3)]">
                    <button
                        onClick={() => {
                            if (state === 'listening') stopListening();
                            else startListening();
                        }}
                        disabled={state === 'thinking' || state === 'speaking'}
                        className={`
                            relative flex-shrink-0 w-16 h-16 md:w-20 md:h-20 rounded-full flex items-center justify-center text-2xl md:text-3xl transition-all duration-300 border-4 border-[#0d1426] active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed
                            ${state === 'listening' ? 'bg-red-500 text-white shadow-[0_0_30px_rgba(239,68,68,0.6)] animate-pulse' : state === 'thinking' || state === 'speaking' ? 'bg-gray-600 text-white cursor-not-allowed' : 'bg-blue-600 text-white hover:bg-blue-500 active:bg-blue-700 shadow-lg hover:shadow-[0_0_20px_rgba(37,99,235,0.5)]'}
                        `}
                    >
                        <span className="relative z-10">{state === 'listening' ? '⏹' : '🎙️'}</span>
                        {state === 'listening' && (
                            <>
                                <span className="absolute inset-0 rounded-full bg-red-400 animate-ping opacity-75"></span>
                                <span className="absolute inset-0 rounded-full bg-red-500 animate-pulse"></span>
                                <motion.span
                                    className="absolute -inset-2 rounded-full border-2 border-green-400 pointer-events-none"
                                    style={{
                                        scale: visualizerScale,
                                        opacity: visualizerOpacity
                                    }}
                                />
                            </>
                        )}
                    </button>

                    <div className="flex-grow min-w-0">
                        <input
                            type="text"
                            placeholder="Escribe tu consulta aquí..."
                            disabled={state === 'listening'}
                            className="w-full bg-transparent border-none text-white text-base md:text-lg placeholder-white/30 focus:ring-0 focus:outline-none px-2 md:px-4 disabled:opacity-50"
                            onKeyDown={(e) => {
                                if (e.key === 'Enter' && e.currentTarget.value.trim()) {
                                    handleQuery(e.currentTarget.value.trim());
                                    e.currentTarget.value = '';
                                }
                            }}
                        />
                    </div>
                    <div className="text-white/20 text-lg md:text-xl flex-shrink-0">↵</div>
                </div>

                {error && (
                    <div className="mt-4 w-full max-w-3xl mx-auto">
                        <div className="bg-red-500/20 border border-red-500/50 rounded-2xl p-4 text-center backdrop-blur-sm">
                            <p className="text-red-300 text-sm md:text-base font-medium">{error}</p>
                        </div>
                    </div>
                )}

                {state === 'thinking' && (
                    <div className="mt-4 w-full max-w-3xl mx-auto">
                        <div className="bg-blue-500/20 border border-blue-500/50 rounded-2xl p-4 text-center backdrop-blur-sm">
                            <p className="text-blue-300 text-sm md:text-base font-medium flex items-center justify-center gap-2">
                                <span className="inline-block w-2 h-2 bg-blue-400 rounded-full animate-bounce"></span>
                                <span className="inline-block w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></span>
                                <span className="inline-block w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                                <span className="ml-2">Procesando tu consulta...</span>
                            </p>
                        </div>
                    </div>
                )}

                <div className="mt-6 text-center">
                    <p className="text-xs text-white/30 font-medium tracking-wide border-b border-white/5 pb-1 inline-block">
                        ⚠️ La respuesta por IA puede contener errores.
                    </p>
                </div>
            </div>

            <AnimatePresence>
                {isModalOpen && (
                    <motion.div
                        className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-6 bg-black/80 backdrop-blur-md"
                        onClick={() => setIsModalOpen(false)}
                    >
                        <div className="glass-effect rounded-2xl md:rounded-[2rem] p-6 md:p-12 max-w-4xl w-full border border-white/10 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
                            <h2 className="text-2xl md:text-4xl text-white mb-6 md:mb-8 text-center md:text-left">Ejemplos de Preguntas</h2>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                                {["Vacaciones", "Seguro Médico", "Horarios", "Permisos"].map((topic, i) => (
                                    <button
                                        key={i}
                                        onClick={() => { setIsModalOpen(false); handleQuery(topic); }}
                                        className="p-6 md:p-8 bg-white/5 hover:bg-white/10 active:bg-white/15 rounded-xl md:rounded-2xl text-left text-lg md:text-2xl text-blue-200 transition-colors border border-white/5 min-h-[60px] md:min-h-auto"
                                    >
                                        {topic}
                                    </button>
                                ))}
                            </div>
                            <div className="mt-6 md:mt-8 text-center">
                                <button onClick={() => setIsModalOpen(false)} className="px-6 py-3 bg-white/10 hover:bg-white/15 active:bg-white/20 rounded-full text-white text-sm md:text-base transition-colors border border-white/20">
                                    Cerrar
                                </button>
                            </div>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>

            {showDebug && (
                <div className="fixed top-0 left-0 w-full h-[40vh] bg-black/95 text-green-400 p-2 z-[200] overflow-y-auto font-mono text-xs border-b border-green-500 shadow-2xl">
                    <div className="flex justify-between items-center mb-2 sticky top-0 bg-black/95 p-2 border-b border-gray-700 z-10">
                        <span className="font-bold text-sm">🖥️ DEBUG CONSOLE</span>
                        <div>
                            <button onClick={() => setDebugLogs([])} className="text-gray-400 hover:text-white px-3 py-1 mr-2 bg-gray-800 rounded">Limpiar</button>
                            <button onClick={() => setShowDebug(false)} className="text-red-400 hover:text-white px-3 py-1 bg-gray-800 rounded font-bold">X</button>
                        </div>
                    </div>
                    <div className="flex flex-col gap-1 p-1">
                        {debugLogs.length === 0 ? (
                            <div className="text-gray-500 italic p-4 text-center">Esperando logs de actividad...</div>
                        ) : (
                            debugLogs.map((log, index) => (
                                <div key={index} className="border-b border-gray-800 pb-1 break-words flex gap-2">
                                    {log}
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )}

            {/* Botón de debug oculto para producción
            <div className="fixed bottom-4 left-4 z-50 pointer-events-auto">
                <button
                    onClick={() => setShowDebug(!showDebug)}
                    className="bg-gray-800/80 backdrop-blur text-white p-3 rounded-full shadow-lg border border-white/10 hover:bg-gray-700 transition-colors"
                >
                    🐞
                </button>
            </div>
            */}
        </div>
    );
};

export default VoiceChat;
